package scheduling;

import javafx.collections.ObservableList;

/**
 * Created by phenicie on 2/21/2017.
 */
public class Appointment {
    // TODO Build Class to match DATABASE



    public ObservableList<Appointment> getAppointments(String interval){
        ObservableList<Appointment> appointments;
        // TODO Pass Interval (by Week, or by Month) Return Appointments


        return appointments;
    }

}
